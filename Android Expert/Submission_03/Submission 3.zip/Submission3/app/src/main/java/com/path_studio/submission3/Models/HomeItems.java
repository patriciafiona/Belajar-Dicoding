package com.path_studio.submission3.Models;

import java.util.ArrayList;

public class HomeItems {

    private ArrayList<String> discover_movie_poster;
    private ArrayList<String> discover_tv_poster;

    public ArrayList<String> getDiscover_movie_poster() {
        return discover_movie_poster;
    }

    public void setDiscover_movie_poster(ArrayList<String> discover_movie_poster) {
        this.discover_movie_poster = discover_movie_poster;
    }

    public ArrayList<String> getDiscover_tv_poster() {
        return discover_tv_poster;
    }

    public void setDiscover_tv_poster(ArrayList<String> discover_tv_poster) {
        this.discover_tv_poster = discover_tv_poster;
    }
}

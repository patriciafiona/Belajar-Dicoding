package com.path_studio.submission_05.Models;

import java.util.ArrayList;

public class HomeTVItems {

    private ArrayList<String> discover_tv_poster;

    public ArrayList<String> getDiscover_tv_poster() {
        return discover_tv_poster;
    }

    public void setDiscover_tv_poster(ArrayList<String> discover_tv_poster) {
        this.discover_tv_poster = discover_tv_poster;
    }
}

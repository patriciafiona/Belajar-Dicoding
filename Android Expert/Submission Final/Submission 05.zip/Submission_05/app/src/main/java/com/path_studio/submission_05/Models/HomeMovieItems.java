package com.path_studio.submission_05.Models;

import java.util.ArrayList;

public class HomeMovieItems {
    private ArrayList<String> discover_movie_poster;

    public ArrayList<String> getDiscover_movie_poster() {
        return discover_movie_poster;
    }

    public void setDiscover_movie_poster(ArrayList<String> discover_movie_poster) {
        this.discover_movie_poster = discover_movie_poster;
    }

}

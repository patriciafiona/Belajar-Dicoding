package com.path_studio.mymovie;

public class YouTubeConfig {

    public YouTubeConfig(){
        //constructor
    }

    private static final String API_KEY = "AIzaSyCqeeFRSaQ5mKwOuR0jfcwbagBONb62q94";

    public static String getApiKey(){
        return API_KEY;
    }

}

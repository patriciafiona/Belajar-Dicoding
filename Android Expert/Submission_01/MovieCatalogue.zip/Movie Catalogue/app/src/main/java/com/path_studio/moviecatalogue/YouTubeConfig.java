package com.path_studio.moviecatalogue;

public class YouTubeConfig {

    public YouTubeConfig(){
        //constructor
    }

    private static final String API_KEY = "AIzaSyAqeB2nX2-Vf5B7ROV8IEalomSczgWWdwg";

    public static String getApiKey(){
        return API_KEY;
    }

}
